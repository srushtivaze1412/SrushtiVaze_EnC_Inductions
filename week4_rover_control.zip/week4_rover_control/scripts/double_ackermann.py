#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64MultiArray


class DoubleAckermannController(Node):

    def __init__(self):
        super().__init__('double_ackermann_controller')

        self.cmd_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_callback,
            10
        )

        self.steer_pub = self.create_publisher(
            Float64MultiArray,
            '/steering_controller/commands',
            10
        )

        self.drive_pub = self.create_publisher(
            Float64MultiArray,
            '/drive_controller/commands',
            10
        )

        self.wheelbase = 0.5
        self.track_width = 0.3
        self.wheel_radius = 0.12

        self.get_logger().info(
            "Double Ackermann Controller Node Started. Waiting for /cmd_vel..."
        )

    def cmd_callback(self, msg):

        linear_x = msg.linear.x
        angular_z = msg.angular.z

        if abs(angular_z) < 1e-6:

            fl_angle = fr_angle = rl_angle = rr_angle = 0.0

            speed = linear_x / self.wheel_radius

            fl_vel = fr_vel = rl_vel = rr_vel = speed

        else:

            R = linear_x / angular_z

            left = R - self.track_width / 2.0
            right = R + self.track_width / 2.0

            fl_angle = math.atan(self.wheelbase / left)
            fr_angle = math.atan(self.wheelbase / right)

            rl_angle = -fl_angle
            rr_angle = -fr_angle

            r_left = math.sqrt(left**2 + (self.wheelbase / 2.0)**2)
            r_right = math.sqrt(right**2 + (self.wheelbase / 2.0)**2)

            fl_vel = angular_z * r_left / self.wheel_radius
            rl_vel = angular_z * r_left / self.wheel_radius

            fr_vel = angular_z * r_right / self.wheel_radius
            rr_vel = angular_z * r_right / self.wheel_radius

        steer_msg = Float64MultiArray()
        steer_msg.data = [fl_angle, fr_angle, rl_angle, rr_angle]
        self.steer_pub.publish(steer_msg)

        drive_msg = Float64MultiArray()
        drive_msg.data = [fl_vel, fr_vel, rl_vel, rr_vel]
        self.drive_pub.publish(drive_msg)


def main(args=None):
    rclpy.init(args=args)
    node = DoubleAckermannController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
